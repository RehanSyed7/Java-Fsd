import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class DisplayFile {
	public void DisplayFile() {
		String path = "D:\\Myfiles\\";
		File f = new File(path);
		File filenames[] = f.listFiles();
		for (File ff : filenames) {
			System.out.println(ff.getName());
		}
	}

}
