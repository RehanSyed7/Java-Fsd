import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class DeleteFile {

	public void DeleteFile() {
		String path = "D:\\Myfiles\\";
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the  filename:");
		String filename = sc.next();
		String finalpath = path + filename;
		File f = new File(finalpath);
		// delete operation
		f.delete();
		System.out.println("file got deleted");

	}
}
