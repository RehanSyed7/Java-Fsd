import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class CreateFile {

	public void CreateFile() throws IOException {
		String path = "D:\\Myfiles\\";
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the  filename:");
		String filename = sc.next();
		String finalpath = path + filename;
		File f = new File(finalpath);
		boolean b = f.createNewFile();
		if (b != true) {
			System.out.println("file is not created");
		} else {
			System.out.println(" file is created");
		}

	}

}
