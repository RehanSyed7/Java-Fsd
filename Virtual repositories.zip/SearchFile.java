import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class SearchFile {
	public void SearchFile() {
		String path = "D:\\Myfiles\\";
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the  filename:");
		String filename = sc.next();
		File f = new File(path);
		int flag = 0;
		File filenames[] = f.listFiles();
		for (File ff : filenames) {
			if (ff.getName().equals(filename)) {
				flag = 1;
				break;
			} else {
				flag = 0;
			}

		}

		if (flag == 1) {
			System.out.println("file is found");

		} else {
			System.out.println("file is not found");

		}
	}
}
